var searchData=
[
  ['prefix_5fcode',['prefix_code',['../structmy_1_1dictionary.html#a89c09af24eef9e0a419ea0d12f416ff8',1,'my::dictionary']]]
];
