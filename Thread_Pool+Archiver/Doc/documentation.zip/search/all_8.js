var searchData=
[
  ['my_5fwrite',['my_write',['../tester_8h.html#afbbc41fba65b405ea14989c3aa7b4d00',1,'my::test']]]
];
