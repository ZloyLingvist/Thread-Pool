var searchData=
[
  ['ownarchiver',['ownarchiver',['../classmy_1_1ownarchiver.html',1,'my']]]
];
