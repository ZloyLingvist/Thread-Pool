var searchData=
[
  ['logging',['logging',['../classmy_1_1test_1_1Testing__class.html#af8d6640e3f3a619b26a7361b27393815',1,'my::test::Testing_class']]]
];
