var searchData=
[
  ['add_5ftask',['add_task',['../structmy_1_1task.html#ae0a98838fdda9b7bcdbe6aa1ec18be8c',1,'my::task']]],
  ['add_5fto_5farchive',['add_to_archive',['../classmy_1_1tarchiver.html#a4f971a32bb3c048644b2cb0e96140e42',1,'my::tarchiver']]],
  ['append_5ffunction',['append_function',['../classmy_1_1Threadpool.html#a85a03c9f7bb463d4c2fbb3f256d26845',1,'my::Threadpool']]]
];
