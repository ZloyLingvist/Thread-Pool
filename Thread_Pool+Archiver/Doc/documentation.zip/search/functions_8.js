var searchData=
[
  ['open_5ffile',['Open_File',['../classmy_1_1ownarchiver.html#a0eb1b800eb6d67358a778472d853aeb4',1,'my::ownarchiver']]],
  ['operator_3c',['operator&lt;',['../structmy_1_1task.html#a4510932d9ee9503ba4022cc8616ec601',1,'my::task']]]
];
