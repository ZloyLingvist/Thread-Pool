var searchData=
[
  ['character',['character',['../structmy_1_1dictionary.html#a55f08a9bfd59980f98d4e96784ca98a5',1,'my::dictionary']]],
  ['code_5fvalue',['code_value',['../structmy_1_1dictionary.html#ac993592c45cd5335c74be18672dd3d47',1,'my::dictionary']]]
];
