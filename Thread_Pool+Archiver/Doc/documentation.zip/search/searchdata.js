var indexSectionsWithContent =
{
  0: "abcdefilmopqstvwÐ",
  1: "bdloqt",
  2: "alot",
  3: "acdefilmopstvw",
  4: "cfp",
  5: "Ð"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Страницы"
};

