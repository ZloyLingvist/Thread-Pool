var searchData=
[
  ['dictionary',['dictionary',['../structmy_1_1dictionary.html',1,'my']]]
];
