var searchData=
[
  ['bi_5ffile',['bi_file',['../structmy_1_1bi__file.html',1,'my']]]
];
