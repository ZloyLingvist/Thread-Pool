var searchData=
[
  ['ownarchiver',['ownarchiver',['../classownarchiver.html',1,'']]]
];
