var searchData=
[
  ['open_5ffile',['Open_File',['../classownarchiver.html#a318cb0494c83417fd8ecdb53605559c7',1,'ownarchiver']]],
  ['operator_3c',['operator&lt;',['../structtask.html#aec1ebec3914bdf72c5179540797eeb87',1,'task']]]
];
