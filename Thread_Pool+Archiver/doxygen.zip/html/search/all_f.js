var searchData=
[
  ['void_5ftask',['void_task',['../tester_8h.html#ae1b596f1d7cf41877aea7e8c69594f26',1,'Testeradd.cpp']]]
];
