var searchData=
[
  ['prefix_5fcode',['prefix_code',['../structdictionary.html#abcfb792af5c244f19a88513581a9a009',1,'dictionary']]]
];
