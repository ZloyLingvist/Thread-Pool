var searchData=
[
  ['character',['character',['../structdictionary.html#a922fb013ee53a02bf32f45e681362725',1,'dictionary']]],
  ['code_5fvalue',['code_value',['../structdictionary.html#afe65a10d699a834bd5187d56d4265473',1,'dictionary']]]
];
