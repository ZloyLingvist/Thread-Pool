var searchData=
[
  ['add_5ffunction',['add_function',['../structtask.html#a6dafba5b1f6f190d53912f4b9df366ea',1,'task::add_function()'],['../classThreadpool.html#a98d532a2d08984aadc53830bf66d5f26',1,'Threadpool::add_function()']]],
  ['add_5ftask',['add_task',['../classTaskQueue.html#afd9b1d9d3148c8b4a9cab171c3f983f1',1,'TaskQueue']]],
  ['add_5fto_5farchive',['add_to_archive',['../classtarchiver.html#a4f971a32bb3c048644b2cb0e96140e42',1,'tarchiver']]]
];
