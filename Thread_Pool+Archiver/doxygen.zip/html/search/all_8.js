var searchData=
[
  ['make_5ftask',['make_task',['../structtask.html#a4af55c2c37c6df7218f4befad621f7a1',1,'task']]]
];
