var searchData=
[
  ['dictionary',['dictionary',['../structdictionary.html',1,'']]]
];
