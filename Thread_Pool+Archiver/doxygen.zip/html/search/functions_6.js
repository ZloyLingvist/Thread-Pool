var searchData=
[
  ['logging',['logging',['../classTesting__class.html#af8d6640e3f3a619b26a7361b27393815',1,'Testing_class']]]
];
