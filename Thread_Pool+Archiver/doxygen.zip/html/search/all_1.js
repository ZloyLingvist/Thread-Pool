var searchData=
[
  ['bi_5ffile',['bi_file',['../structbi__file.html',1,'']]]
];
